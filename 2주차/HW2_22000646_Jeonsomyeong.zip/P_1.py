C = float(input("섭씨 온도를 입력하시오:"))
F = C*1.8+32

print(F,"F")

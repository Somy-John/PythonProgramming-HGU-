Y = int(input("출생년도를 입력하시오:"))

O = 2020 - Y + 1

print(O,"세")

SUM = 0

for i in range(1,500):
    SUM += 2 * i

print("1과 1000사이의 모든 짝수의 합계는 %d 입니다."%SUM)

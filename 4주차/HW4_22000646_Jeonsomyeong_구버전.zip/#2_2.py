SUM = 0

print("10과 25사이의 정수를 누적하여 더한 값은")

for i in range(11,25):
    SUM += i
    print(SUM)

print("입니다")

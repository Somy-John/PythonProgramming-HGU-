print("3의 제곱부터 50제곱은")

for i in range(0,51):
    print(3**i)

print("입니다.")

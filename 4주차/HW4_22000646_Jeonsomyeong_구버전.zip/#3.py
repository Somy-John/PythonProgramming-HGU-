n = int(input("정수를 입력하시오 : "))
f = 1

if n > 0:
    for j in range(n):
        f *= j+1
        J = j+1
        if j == n-1:
            print("%d! = %d"%(J,f) , end = "")
        else:
            print("%d! = %d"%(J,f) , end = ", ")

else:
    print("양의 정수가 아니기 때문에 계산 할 수 없습니다.")

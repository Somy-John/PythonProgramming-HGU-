def reverse(s3):
  result = ''.join(reversed(s3))
  return result

print(reverse("hello"))
print(reverse("Python"))

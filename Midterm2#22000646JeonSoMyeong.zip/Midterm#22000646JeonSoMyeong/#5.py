n = open("poem.txt","w")
n.write("I can carry your heart")
n.write("I am never without it")
n.write("I fear no fate")
n.close
print(n)
#def fileIO(input, output):
